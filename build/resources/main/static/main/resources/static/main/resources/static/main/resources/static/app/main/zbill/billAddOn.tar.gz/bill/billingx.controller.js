(function() {
  'use strict';

  angular
    .module('k7')
    .controller('BillingxController', BillingxController)
    .filter('StatP', StatP)

    function StatP() {
      return function(st) {
             if (st == 0) { return "OPEN" }
        else if (st == 1) { return "GENERATED" }
        else if (st >= 3) { return "CLOSED" }
        else              { return "NULL" }
      }
    }


  /** @ngInject */
  function BillingxController($http, $stateParams) {
    var vm = this;

    vm.dbg = false;

    vm.pdr = $stateParams.pdr;

    vm.abc = 'abc';
    vm.dta = [{
      "pdr": "1609",
      "sta": "0",
      "grp": "1",
      "pds": "2016-09-01 00:00:00",
      "xdt": "2016-09-13 15:12:49",
      "due": null
    }];

    $http.get("api/billingshow/"+vm.pdr)
    .then(function(response) {
      vm.dta = response.data;
    });

    vm.info = vm.dta;
  }
})();
